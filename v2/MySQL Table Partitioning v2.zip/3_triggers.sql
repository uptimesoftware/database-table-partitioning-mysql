CREATE TRIGGER trig_p_aggregate BEFORE INSERT ON performance_aggregate
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_cpu BEFORE INSERT ON performance_cpu
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_disk BEFORE INSERT ON performance_disk
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_disk_total BEFORE INSERT ON performance_disk_total
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_esx3_workload BEFORE INSERT ON performance_esx3_workload
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_fscap BEFORE INSERT ON performance_fscap
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_lpar_workload BEFORE INSERT ON performance_lpar_workload
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_network BEFORE INSERT ON performance_network
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_nrm BEFORE INSERT ON performance_nrm
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_psinfo BEFORE INSERT ON performance_psinfo
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_vxvol BEFORE INSERT ON performance_vxvol
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);

CREATE TRIGGER trig_p_who BEFORE INSERT ON performance_who
FOR EACH ROW SET NEW.sample_time = 
(SELECT sample_time from performance_sample ps where ps.id = NEW.sample_id);
