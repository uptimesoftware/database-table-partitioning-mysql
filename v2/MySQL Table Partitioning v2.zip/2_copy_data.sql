INSERT INTO performance_sample_par SELECT * FROM performance_sample;
RENAME TABLE performance_sample TO performance_sample_ori;
RENAME TABLE performance_sample_par TO performance_sample;

INSERT INTO performance_aggregate_par SELECT p.*, ps.sample_time FROM performance_aggregate p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_aggregate TO performance_aggregate_ori;
RENAME TABLE performance_aggregate_par TO performance_aggregate;
DROP TABLE IF EXISTS performance_aggregate_ori;

INSERT INTO performance_cpu_par SELECT p.*, ps.sample_time FROM performance_cpu p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_cpu TO performance_cpu_ori;
RENAME TABLE performance_cpu_par TO performance_cpu;
DROP TABLE IF EXISTS performance_cpu_ori;

INSERT INTO performance_disk_par SELECT p.*, ps.sample_time FROM performance_disk p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_disk TO performance_disk_ori;
RENAME TABLE performance_disk_par TO performance_disk;
DROP TABLE IF EXISTS performance_disk_ori;

INSERT INTO performance_disk_total_par SELECT p.*, ps.sample_time FROM performance_disk_total p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_disk_total TO performance_disk_total_ori;
RENAME TABLE performance_disk_total_par TO performance_disk_total;
DROP TABLE IF EXISTS performance_disk_total_ori;

INSERT INTO performance_esx3_workload_par SELECT p.*, ps.sample_time FROM performance_esx3_workload p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_esx3_workload TO performance_esx3_workload_ori;
RENAME TABLE performance_esx3_workload_par TO performance_esx3_workload;
DROP TABLE IF EXISTS performance_esx3_workload_ori;

INSERT INTO performance_fscap_par SELECT p.*, ps.sample_time FROM performance_fscap p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_fscap TO performance_fscap_ori;
RENAME TABLE performance_fscap_par TO performance_fscap;
DROP TABLE IF EXISTS performance_fscap_ori;

INSERT INTO performance_lpar_workload_par SELECT p.*, ps.sample_time FROM performance_lpar_workload p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_lpar_workload TO performance_lpar_workload_ori;
RENAME TABLE performance_lpar_workload_par TO performance_lpar_workload;
DROP TABLE IF EXISTS performance_lpar_workload_ori;

INSERT INTO performance_network_par SELECT p.*, ps.sample_time FROM performance_network p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_network TO performance_network_ori;
RENAME TABLE performance_network_par TO performance_network;
DROP TABLE IF EXISTS performance_network_ori;

INSERT INTO performance_nrm_par SELECT p.*, ps.sample_time FROM performance_nrm p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_nrm TO performance_nrm_ori;
RENAME TABLE performance_nrm_par TO performance_nrm;
DROP TABLE IF EXISTS performance_nrm_ori;

INSERT INTO performance_psinfo_par SELECT p.*, ps.sample_time FROM performance_psinfo p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_psinfo TO performance_psinfo_ori;
RENAME TABLE performance_psinfo_par TO performance_psinfo;
DROP TABLE IF EXISTS performance_psinfo_ori;

INSERT INTO performance_vxvol_par SELECT p.*, ps.sample_time FROM performance_vxvol p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_vxvol TO performance_vxvol_ori;
RENAME TABLE performance_vxvol_par TO performance_vxvol;
DROP TABLE IF EXISTS performance_vxvol_ori;

INSERT INTO performance_who_par SELECT p.*, ps.sample_time FROM performance_who p, performance_sample ps WHERE p.sample_id = ps.id;
RENAME TABLE performance_who TO performance_who_ori;
RENAME TABLE performance_who_par TO performance_who;
DROP TABLE IF EXISTS performance_who_ori;


DROP TABLE IF EXISTS performance_sample_ori;


INSERT INTO erdc_decimal_data_par SELECT * FROM erdc_decimal_data;
RENAME TABLE erdc_decimal_data TO erdc_decimal_data_ori;
RENAME TABLE erdc_decimal_data_par TO erdc_decimal_data;
DROP TABLE IF EXISTS erdc_decimal_data_ori;

INSERT INTO erdc_int_data_par SELECT * FROM erdc_int_data;
RENAME TABLE erdc_int_data TO erdc_int_data_ori;
RENAME TABLE erdc_int_data_par TO erdc_int_data;
DROP TABLE IF EXISTS erdc_int_data_ori;

INSERT INTO erdc_string_data_par SELECT * FROM erdc_string_data;
RENAME TABLE erdc_string_data TO erdc_string_data_ori;
RENAME TABLE erdc_string_data_par TO erdc_string_data;
DROP TABLE IF EXISTS erdc_string_data_ori;

INSERT INTO ranged_object_value_par SELECT * FROM ranged_object_value;
RENAME TABLE ranged_object_value TO ranged_object_value_ori;
RENAME TABLE ranged_object_value_par TO ranged_object_value;
DROP TABLE IF EXISTS ranged_object_value_ori;
